﻿using System;

namespace UniqueNames
{
    class Program
    {
        public static bool IsTypo(string name1, string name2) // seeing if two names are different or there is a typo
        {
            if (name1 == name2) return true; // same name
            if (name1.Length == 1 && name2.Length == 1) return false;

            int i; // checking which name is longer
            if (name1.Length > name2.Length) i = name2.Length;
            else i = name1.Length;

            int differentCharacters = Math.Abs(name1.Length - name2.Length);

            for (int j = 0; j < i; j++) // looping throught the shoreter name
                if (name1[j] != name2[j]) differentCharacters++; // 

            return (differentCharacters <= 2); // assuming only two different characters between two names count as the same name
        }

        public static string[] GetNicknames(string name) // returning the nicknames of a name
        {
            string path = @"C:\Users\Owner\Desktop\UniqueNames\UniqueNames\names.csv";

            string[] lines = System.IO.File.ReadAllLines(path); // accessing the database
            foreach (string line in lines)
            {
                string[] columns = line.Split(',');
                foreach (string column in columns)
                {
                    if (column == name)
                        return columns; // returning the first name in the line where the name was found
                }
            }
            return null;
        }

        public static bool IsSameName(string name1, string name2) // checking if two names are the same name
        {
            if (name1 == name2) return true; // the names are exactly the same

            string[] nicknames = GetNicknames(name1); // getting the nicknames of name1
            if(nicknames==null) nicknames= GetNicknames(name2); // getting the nicknames of name2 if name1 is not in the database
            if (nicknames == null) nicknames = new string[] { name1}; // the nickname of name1 is name1 itself, if name2 is also not found in the database

            bool f1 = false, f2 = false;

            foreach(string name in nicknames) // comparing name1 and name2 with each nickname of name1/name2
            {
                if(!f1) 
                    if (IsTypo(name, name1)) 
                        f1 = true;
                if (!f2)
                    if (IsTypo(name, name2)) 
                        f2 = true;
            }

            return (f1 && f2);
        }
        public static int countUniqueNames(string billFirstName, string billLastName, string shipFirstName, string shipLastName, string billNameOnCard)
        {
            int count = 1;

            billFirstName = billFirstName.ToLower(); // turning all names to lower case because the names in the database are all lower cases
            billLastName = billLastName.ToLower();
            shipFirstName = shipFirstName.ToLower();
            shipLastName = shipLastName.ToLower();
            billNameOnCard = billNameOnCard.ToLower();

            string cardName1 = billNameOnCard.Substring(0, billNameOnCard.IndexOf(' ')); // splitting the name on card to 3 names
            string cardName3 = billNameOnCard.Substring(billNameOnCard.LastIndexOf(' ') + 1);
            string cardName2 = "";
            if (billNameOnCard.IndexOf(' ') != billNameOnCard.LastIndexOf(' '))
            {
                cardName2 = billNameOnCard.Substring(billNameOnCard.IndexOf(' ') + 1, billNameOnCard.LastIndexOf(' ') - billNameOnCard.IndexOf(' ') - 1);
            }

            string billMiddleName = ""; // getting the middle names from billFirstName and shipFirstName
            string shipMiddleName = "";
            if (billFirstName.Contains(' '))
            {
                billMiddleName = billFirstName.Substring(billFirstName.IndexOf(' ') + 1); // getting the middle name of the billing nam
                billFirstName = billFirstName.Substring(0, billFirstName.IndexOf(' ')); // getting the first name of the billing name
            }
            if (shipFirstName.Contains(' '))
            {
                shipMiddleName = shipFirstName.Substring(shipFirstName.IndexOf(' ') + 1); // getting the middle name of the shipping name
                shipFirstName = shipFirstName.Substring(0, shipFirstName.IndexOf(' '));// getting the first name of the shipping name
            }

            if (!IsSameName(billFirstName, shipFirstName)) count++; // if billFirstName and shipFirstName are different, adding a unique name
            else
            {
                if (!IsSameName(billMiddleName, shipMiddleName)) // adding a unique name if the first names are the same but the middle names are different
                {
                    if (billMiddleName.Length == 1) // checking if the middle names start with the same letter in case the middle name is just one letter
                    {
                        if (billMiddleName[0] != shipMiddleName[0]) count++;
                    }
                    else
                    {
                        if (shipMiddleName.Length == 1)
                        {
                            if (billMiddleName[0] != shipMiddleName[0]) count++;
                        }
                        else count++;
                    }
                    
                }
                else
                    if (!IsSameName(billLastName, shipLastName)) count++;// adding a unique name if the middle names are the same but the last names are different
            }

            //adding a unique name if the name on card is different from both the billing and the shipping name
            if (!((IsSameName(billFirstName, cardName1) || IsSameName(billFirstName, cardName2) || IsSameName(billFirstName, cardName3)) || (IsSameName(shipFirstName, cardName1) || IsSameName(shipFirstName, cardName2) || IsSameName(shipFirstName, cardName3)))) count++;
            else
            {
                if (!((IsSameName(billMiddleName, cardName1) || IsSameName(billMiddleName, cardName2) || IsSameName(billMiddleName, cardName3)) || (IsSameName(shipMiddleName, cardName1) || IsSameName(shipMiddleName, cardName2) || IsSameName(shipMiddleName, cardName3)))) 
                {
                    if (cardName1.Length == 1)
                    {
                        if (cardName1[0] != billMiddleName[0] && cardName1[0] != shipMiddleName[0]) count++;
                    }
                    else
                    {
                        if (cardName2.Length == 1)
                        {
                            if (cardName2[0] != billMiddleName[0] && cardName2[0] != shipMiddleName[0]) count++;
                        }
                        else
                        {
                            if (cardName3.Length == 1)
                            {
                                if (cardName3[0] != billMiddleName[0] && cardName3[0] != shipMiddleName[0]) count++;
                            }
                            else count++;
                        }
                    }
                }
                else
                    if (!((IsSameName(billLastName, cardName1) || IsSameName(billLastName, cardName2) || IsSameName(billLastName, cardName3)) || (IsSameName(shipLastName, cardName1) || IsSameName(shipLastName, cardName2) || IsSameName(shipLastName, cardName3)))) count++;
            }

            return count;
        }
        static void Main(string[] args)
        {
            if (countUniqueNames("Deborah", "Egli", "Deborah", "Egli", "Deborah Egli") != 1) Console.WriteLine("Test 1 failed");
            else Console.WriteLine("Test 1 passed");
            if (countUniqueNames("Deborah", "Egli", "Debbie", "Egli", "Debbie Egli") != 1) Console.WriteLine("Test 2 failed");
            else Console.WriteLine("Test 2 passed");
            if (countUniqueNames("Deborah", "Egni", "Deborah", "Egli", "Deborah Egli") != 1) Console.WriteLine("Test 3 failed");
            else Console.WriteLine("Test 3 passed");
            if (countUniqueNames("Deborah S", "Egli", "Deborah", "Egli", "Egli Deborah") != 1) Console.WriteLine("Test 4 failed");
            else Console.WriteLine("Test 4 passed");
            if (countUniqueNames("Michele", "Egli", "Deborah", "Egli", "Michele Egli") != 2) Console.WriteLine("Test 5 failed");
            else Console.WriteLine("Test 5 passed");
            if (countUniqueNames("Dana", "Friedman", "Deborah", "Egli", "Moshe Cohen") != 3) Console.WriteLine("Test 6 failed");
            else Console.WriteLine("Test 6 passed");
            if (countUniqueNames("Deborah", "Friedman", "Debobah", "Egli", "Deborah Egli") != 2) Console.WriteLine("Test 7 failed");
            else Console.WriteLine("Test 7 passed");
            if (countUniqueNames("Deborat", "Egni", "Debbie", "Egli", "Deborah Egli") != 1) Console.WriteLine("Test 8 failed");
            else Console.WriteLine("Test 8 passed");
            if (countUniqueNames("Deborah S", "Egni", "Debbie Sarah", "Egli", "Deborah Egli") != 1) Console.WriteLine("Test 9 failed");
            else Console.WriteLine("Test 9 passed");
            if (countUniqueNames("Deborah S", "Egni", "Debbie Sarah", "Egli", "Deborah M Egli") != 2) Console.WriteLine("Test 10 failed");
            else Console.WriteLine("Test 10 passed");
        }
    }
}
